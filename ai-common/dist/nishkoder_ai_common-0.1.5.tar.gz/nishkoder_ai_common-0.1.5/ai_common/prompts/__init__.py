from .generic_prompts import GenericPrompts, get_generic_prompt

__all__ = ["GenericPrompts", "get_generic_prompt"]
